#include "MonsterState.h"

void MonsterMoveRand::Enter(Monster* obj)
{
}
void MonsterMoveRand::Execute(Monster* obj)
{
}
void MonsterMoveRand::Exit(Monster* obj)
{
}